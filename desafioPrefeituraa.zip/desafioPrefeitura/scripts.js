// Carrossel de Slides
let currentSlide = 0;

function moveSlide(direction) {
    const slides = document.querySelectorAll('.slide');
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    slides[currentSlide].classList.add('active');
}

// Troca de Texto ao Clicar na Imagem 1
function changeTextImg1() {
    const textContainer = document.getElementById('text-container');
    textContainer.innerHTML = `
        <strong>
            <h1>O que é o Lorem Ipsum?</h1>
        </strong>
        <strong>
            <h3>Por que é que o usamos?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum.</p>
        <strong>
            <h3>De onde é que ele vem?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum</p>
        <strong>
            <h3>Onde posso arranjar algum?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum.</p>
    `;
}

// Troca de Texto ao Clicar na Imagem 2
function changeTextImg2() {
    const textContainer = document.getElementById('text-container');
    textContainer.innerHTML = `
        <strong>
            <h1>O que é o Lorem Ipsum?</h1>
        </strong>
        <strong>
            <h3>Por que é que o usamos?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum</p>
    `;
}

// Troca de Texto ao Clicar na Imagem 3 com Animação
function changeTextImg3() {
    const textContainer = document.getElementById('text-container');
    textContainer.innerHTML = `
        <strong>
            <h1 class="slide-in-right">O que é o Lorem Ipsum?</h1>
        </strong>
        <strong>
            <h3 class="slide-in-right">Por que é que o usamos?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum.</p>
        <strong>
            <h3 class="slide-in-right">De onde é que ele vem?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum</p>
        <strong>
            <h3 class="slide-in-right">Onde posso arranjar algum?</h3>
        </strong>
        <p>Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões de Lorem Ipsum.</p>
    `;
}

// Mudar automaticamente de slide a cada 5 segundos
setInterval(() => {
    moveSlide(1);
}, 9000);
